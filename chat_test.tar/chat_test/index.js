const startBtn = document.querySelector("#start-btn");
const stopBtn = document.querySelector("#stop-btn");
const resetBtn = document.querySelector("#reset-btn");
const minutesDisplay = document.querySelector("#minutes");
const secondsDisplay = document.querySelector("#seconds");
const millisecondsDisplay = document.querySelector("#milliseconds");

let interval;
let startTime;

startBtn.addEventListener("click", startStopwatch);
stopBtn.addEventListener("click", stopStopwatch);
resetBtn.addEventListener("click", resetStopwatch);

function startStopwatch() {
  startBtn.setAttribute("disabled", true);
  stopBtn.removeAttribute("disabled");
  resetBtn.setAttribute("disabled", true);
  startTime = Date.now();
  interval = setInterval(updateStopwatch, 10);
}

function stopStopwatch() {
  startBtn.removeAttribute("disabled");
  stopBtn.setAttribute("disabled", true);
  resetBtn.removeAttribute("disabled");
  clearInterval(
